﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3.formy;

namespace WindowsFormsApp3
{
 
    public partial class Form1 : Form
    {
        Form2 f2;
        int i = 0;
        public Form1()
        {
            InitializeComponent();
        }

        
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            i = 1;
            f2 = new Form2(i);
            f2.figura_obrazek.Load("obrazki\\trojkat.jpg");
            f2.label_figura.Text = "wybrałeś trójkąt";
            f2.pole_tekstowe_r.Visible = true;
            f2.pole_tekstowe_r.Enabled = false;
            f2.dlugosc_boku_r.Visible = true;
            f2.dlugosc_boku_r.Enabled = false;

            f2.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            i = 2;
            f2 = new Form2(i);
            f2.figura_obrazek.Load("obrazki\\kwadrat.jpg");
            f2.label_figura.Text = "wybrałeś kwadrat";

            f2.pole_tekstowe_r.Visible = true;
            f2.pole_tekstowe_r.Enabled = false;
            f2.dlugosc_boku_r.Visible = true;
            f2.dlugosc_boku_r.Enabled = false;
            f2.pole_tekstowe_c.Visible = true;
            f2.pole_tekstowe_c.Enabled = false;
            f2.dlugosc_boku_c.Visible = true;
            f2.dlugosc_boku_c.Enabled = false;
            f2.pole_tekstowe_h.Visible = true;
            f2.pole_tekstowe_h.Enabled = false;
            f2.dlugosc_boku_h.Visible = true;
            f2.dlugosc_boku_h.Enabled = false;
            f2.pole_tekstowe_b.Visible = true;
            f2.pole_tekstowe_b.Enabled = false;
            f2.dlugosc_boku_b.Visible = true;
            f2.dlugosc_boku_b.Enabled = false;


            f2.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            i = 3;
            f2 = new Form2(i);
            f2.figura_obrazek.Load("obrazki\\kolo.jpg");
            f2.label_figura.Text = "wybrałeś koło";
            f2.pole_tekstowe_a.Visible = true;
            f2.pole_tekstowe_a.Enabled = false;
            f2.dlugosc_boku_a.Visible = true;
            f2.dlugosc_boku_a.Enabled = false;
            f2.pole_tekstowe_c.Visible = true;
            f2.pole_tekstowe_c.Enabled = false;
            f2.dlugosc_boku_c.Visible = true;
            f2.dlugosc_boku_c.Enabled = false;
            f2.pole_tekstowe_h.Visible = true;
            f2.pole_tekstowe_h.Enabled = false;
            f2.dlugosc_boku_h.Visible = true;
            f2.dlugosc_boku_h.Enabled = false;
            f2.pole_tekstowe_b.Visible = true;
            f2.pole_tekstowe_b.Enabled = false;
            f2.dlugosc_boku_b.Visible = true;
            f2.dlugosc_boku_b.Enabled = false;

            f2.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            i = 4;
            f2 = new Form2(i);
            f2.figura_obrazek.Load("obrazki\\prostokat.jpg");
            f2.label_figura.Text = "wybrałeś prostokąt";

            f2.pole_tekstowe_r.Visible = true;
            f2.pole_tekstowe_r.Enabled = false;
            f2.dlugosc_boku_r.Visible = true;
            f2.dlugosc_boku_r.Enabled = false;
            f2.pole_tekstowe_c.Visible = true;
            f2.pole_tekstowe_c.Enabled = false;
            f2.dlugosc_boku_c.Visible = true;
            f2.dlugosc_boku_c.Enabled = false;
            f2.pole_tekstowe_h.Visible = true;
            f2.pole_tekstowe_h.Enabled = false;
            f2.dlugosc_boku_h.Visible = true;
            f2.dlugosc_boku_h.Enabled = false;


            f2.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            i = 5;
            f2 = new Form2(i);

            f2.Show();
            f2.figura_obrazek.Load("obrazki\\osmiokat_foremny.jpg");
            f2.label_figura.Text = "wybrałeś ośmiokąt foremny";
            f2.pole_tekstowe_r.Visible = true;
            f2.pole_tekstowe_r.Enabled = false;
            f2.dlugosc_boku_r.Visible = true;
            f2.dlugosc_boku_r.Enabled = false;
            f2.pole_tekstowe_c.Visible = true;
            f2.pole_tekstowe_c.Enabled = false;
            f2.dlugosc_boku_c.Visible = true;
            f2.dlugosc_boku_c.Enabled = false;
            f2.pole_tekstowe_h.Visible = true;
            f2.pole_tekstowe_h.Enabled = false;
            f2.dlugosc_boku_h.Visible = true;
            f2.dlugosc_boku_h.Enabled = false;
            f2.pole_tekstowe_b.Visible = true;
            f2.pole_tekstowe_b.Enabled = false;
            f2.dlugosc_boku_b.Visible = true;
            f2.dlugosc_boku_b.Enabled = false;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
