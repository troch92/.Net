﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3.formy
{
    public partial class Form2 : Form
    {
        double pole, obwod;
        Form3 f3;
        public Form2(int i)
        {

            this.i = i;
            InitializeComponent();

        }
        double a, b, c, h, r;
        double pi = 3.14; // przyblizona wartość pi
        public int i;

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private double Oblicz_obwod_trojkata(double a, double b, double c)
        {
            double obwod_trojkata = a + b + c;
            return obwod_trojkata;
        }
        private double Oblicz_pole_trojkata(double a, double h)
        {
            double pole_trojkata = ((a * h * c) / 2);
            return pole_trojkata;
        }
        /*
        private Boolean walidacja_trojkata(double a, double b, double c)
        {
            if (a < (b + c) || b < (a + c) || c < (a + b) )
            {
                return true;
            }
            else return false;
        }
        */
        private double Oblicz_obwod_kwadratu(double a)
        {
            double obwod_kwadratu = (a * 4);
            return obwod_kwadratu;
        }
        private double Oblicz_pole_kwadratu(double a)
        {
            double pole_kwadratu = (a * a);
            return pole_kwadratu;
        }
        private double Oblicz_obwod_prostokatu(double a, double b)
        {
            double obwod_prostokatu = ((2*a)+(2 * b));
            return obwod_prostokatu;
        }

        private void figura_obrazek_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private double Oblicz_pole_prostokatu(double a, double b)
        {
            double pole_prostokatu = (a * b);
            return pole_prostokatu;
        }

        private double Oblicz_obwod_kola(double r)
        {

            double obwod_kola = (2 * pi * r);
            return obwod_kola;
        }

        private double Oblicz_pole_kola(double r)
        {
            double pole_kola = (pi * (r * r));
            return pole_kola;
        }

        private double Oblicz_obwod_osmiokata_foremnego(double a)
        {
            double obwod_osmiokata_foremnego = (8 * a);
            return obwod_osmiokata_foremnego;
        }

        private double Oblicz_pole_osmiokata_foremnego(double a)
        {
            double pole_osmiokata_foremnego = (2 * (1 + (Math.Sqrt(2))) * (a * a));
            return pole_osmiokata_foremnego;
        }
        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        { 
  
            switch (i)

            {
                case 1:
                    a = Convert.ToDouble(this.pole_tekstowe_a.Text);
                    b = Convert.ToDouble(this.pole_tekstowe_b.Text);
                    c = Convert.ToDouble(this.pole_tekstowe_c.Text);
                    h = Convert.ToDouble(this.pole_tekstowe_h.Text);
                    double j, k, l;
                    int y = 0;
                    j = b + c;
                    k = a + c;
                    l = a + b;
                    if (a < j && b < k && c < l)
                    {
                        pole = Oblicz_pole_trojkata(a, h);
                        obwod = Oblicz_obwod_trojkata(a, b, c);

                    }
                    else
                    {
                        this.pole_tekstowe_a.Text = String.Empty;
                        this.pole_tekstowe_b.Text = String.Empty;
                        this.pole_tekstowe_c.Text = String.Empty;
                        this.pole_tekstowe_h.Text = String.Empty;
                        this.Close();
                    }
                    break;
                case 2:
                    a = Convert.ToDouble(this.pole_tekstowe_a.Text);
                    pole=Oblicz_pole_kwadratu(a);
                    obwod=Oblicz_obwod_kwadratu(a);
                    break;
                case 3:
                    r = Convert.ToDouble(this.pole_tekstowe_r.Text);
                    pole=Oblicz_pole_kola(r);
                    obwod=Oblicz_obwod_kola(r);
                    break;
                case 4:
                    a = Convert.ToDouble(this.pole_tekstowe_a.Text);
                    b = Convert.ToDouble(this.pole_tekstowe_b.Text);
                    pole=Oblicz_pole_prostokatu(a,b);
                    obwod=Oblicz_obwod_prostokatu(a,b);
                    break;
                case 5:
                    a = Convert.ToDouble(this.pole_tekstowe_a.Text);
                    pole=Oblicz_pole_osmiokata_foremnego(a);
                    obwod=Oblicz_obwod_osmiokata_foremnego(a);
                    break;
            }
            /*
            a = Convert.ToDouble(this.pole_tekstowe_a.Text);
            b = Convert.ToDouble(this.pole_tekstowe_b.Text);
            c = Convert.ToDouble(this.pole_tekstowe_c.Text);
            r = Convert.ToDouble(this.pole_tekstowe_r.Text);
            h = Convert.ToDouble(this.pole_tekstowe_h.Text);

            if (a < (b + c) || b < (a + c) || c < (a + b))
            {
                this.pole_tekstowe_a.Text = String.Empty;
                this.pole_tekstowe_b.Text = String.Empty;
                this.pole_tekstowe_c.Text = String.Empty;
                this.pole_tekstowe_h.Text = String.Empty;
            }
            
            double pole = Oblicz_pole_kwadratu(a);
            double obwod = Oblicz_obwod_kwadratu(a);
            */
            f3 = new Form3(obwod, pole); // wywołanie trzeciego ekranu po naciśnięciu buttona
            f3.Show();
            if (pole!=0)
            {
                f3.pole_figury.Text = "Pole wynosi: " + (pole.ToString()) + ".";
                f3.obwod_figury.Text = "Obwód wynosi: " + (obwod.ToString()) + ".";
            }
            else
            {
                f3.pole_figury.Text = "Trójkąt o podanych bokach";
                f3.obwod_figury.Text = "NIE ISTNIEJE!";
            }






        }

        
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        

    }
}
