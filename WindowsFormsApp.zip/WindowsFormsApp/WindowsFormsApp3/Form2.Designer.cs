﻿namespace WindowsFormsApp3.formy
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.figura_obrazek = new System.Windows.Forms.PictureBox();
            this.label_figura = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dlugosc_boku_a = new System.Windows.Forms.Label();
            this.dlugosc_boku_b = new System.Windows.Forms.Label();
            this.dlugosc_boku_c = new System.Windows.Forms.Label();
            this.dlugosc_boku_r = new System.Windows.Forms.Label();
            this.dlugosc_boku_h = new System.Windows.Forms.Label();
            this.pole_tekstowe_a = new System.Windows.Forms.TextBox();
            this.pole_tekstowe_b = new System.Windows.Forms.TextBox();
            this.pole_tekstowe_c = new System.Windows.Forms.TextBox();
            this.pole_tekstowe_r = new System.Windows.Forms.TextBox();
            this.pole_tekstowe_h = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.figura_obrazek)).BeginInit();
            this.SuspendLayout();
            // 
            // figura_obrazek
            // 
            this.figura_obrazek.Location = new System.Drawing.Point(12, 37);
            this.figura_obrazek.Name = "figura_obrazek";
            this.figura_obrazek.Size = new System.Drawing.Size(400, 400);
            this.figura_obrazek.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.figura_obrazek.TabIndex = 0;
            this.figura_obrazek.TabStop = false;
            this.figura_obrazek.Click += new System.EventHandler(this.figura_obrazek_Click);
            // 
            // label_figura
            // 
            this.label_figura.AutoSize = true;
            this.label_figura.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_figura.Location = new System.Drawing.Point(12, 9);
            this.label_figura.Name = "label_figura";
            this.label_figura.Size = new System.Drawing.Size(76, 25);
            this.label_figura.TabIndex = 1;
            this.label_figura.Text = "label1";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(418, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(379, 58);
            this.label1.TabIndex = 2;
            this.label1.Text = "Podaj odpowiednie wymiary, aby obliczyć pole i obwód danej figury.";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Info;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(523, 311);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(176, 61);
            this.button1.TabIndex = 3;
            this.button1.Text = "Oblicz!";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dlugosc_boku_a
            // 
            this.dlugosc_boku_a.AutoSize = true;
            this.dlugosc_boku_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dlugosc_boku_a.Location = new System.Drawing.Point(448, 118);
            this.dlugosc_boku_a.Name = "dlugosc_boku_a";
            this.dlugosc_boku_a.Size = new System.Drawing.Size(163, 24);
            this.dlugosc_boku_a.TabIndex = 4;
            this.dlugosc_boku_a.Text = "podaj długość a";
            this.dlugosc_boku_a.Click += new System.EventHandler(this.label2_Click);
            // 
            // dlugosc_boku_b
            // 
            this.dlugosc_boku_b.AutoSize = true;
            this.dlugosc_boku_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dlugosc_boku_b.Location = new System.Drawing.Point(448, 144);
            this.dlugosc_boku_b.Name = "dlugosc_boku_b";
            this.dlugosc_boku_b.Size = new System.Drawing.Size(164, 24);
            this.dlugosc_boku_b.TabIndex = 5;
            this.dlugosc_boku_b.Text = "podaj długość b";
            this.dlugosc_boku_b.Click += new System.EventHandler(this.label3_Click);
            // 
            // dlugosc_boku_c
            // 
            this.dlugosc_boku_c.AutoSize = true;
            this.dlugosc_boku_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dlugosc_boku_c.Location = new System.Drawing.Point(448, 168);
            this.dlugosc_boku_c.Name = "dlugosc_boku_c";
            this.dlugosc_boku_c.Size = new System.Drawing.Size(163, 24);
            this.dlugosc_boku_c.TabIndex = 6;
            this.dlugosc_boku_c.Text = "podaj długość c";
            this.dlugosc_boku_c.Click += new System.EventHandler(this.label4_Click);
            // 
            // dlugosc_boku_r
            // 
            this.dlugosc_boku_r.AutoSize = true;
            this.dlugosc_boku_r.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dlugosc_boku_r.Location = new System.Drawing.Point(448, 192);
            this.dlugosc_boku_r.Name = "dlugosc_boku_r";
            this.dlugosc_boku_r.Size = new System.Drawing.Size(159, 24);
            this.dlugosc_boku_r.TabIndex = 7;
            this.dlugosc_boku_r.Text = "podaj długość r";
            this.dlugosc_boku_r.Click += new System.EventHandler(this.label5_Click);
            // 
            // dlugosc_boku_h
            // 
            this.dlugosc_boku_h.AutoSize = true;
            this.dlugosc_boku_h.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dlugosc_boku_h.Location = new System.Drawing.Point(448, 216);
            this.dlugosc_boku_h.Name = "dlugosc_boku_h";
            this.dlugosc_boku_h.Size = new System.Drawing.Size(164, 24);
            this.dlugosc_boku_h.TabIndex = 8;
            this.dlugosc_boku_h.Text = "podaj długość h";
            this.dlugosc_boku_h.Click += new System.EventHandler(this.label6_Click);
            // 
            // pole_tekstowe_a
            // 
            this.pole_tekstowe_a.Location = new System.Drawing.Point(617, 122);
            this.pole_tekstowe_a.Name = "pole_tekstowe_a";
            this.pole_tekstowe_a.Size = new System.Drawing.Size(142, 20);
            this.pole_tekstowe_a.TabIndex = 9;
            // 
            // pole_tekstowe_b
            // 
            this.pole_tekstowe_b.Location = new System.Drawing.Point(617, 148);
            this.pole_tekstowe_b.Name = "pole_tekstowe_b";
            this.pole_tekstowe_b.Size = new System.Drawing.Size(142, 20);
            this.pole_tekstowe_b.TabIndex = 10;
            // 
            // pole_tekstowe_c
            // 
            this.pole_tekstowe_c.Location = new System.Drawing.Point(617, 172);
            this.pole_tekstowe_c.Name = "pole_tekstowe_c";
            this.pole_tekstowe_c.Size = new System.Drawing.Size(142, 20);
            this.pole_tekstowe_c.TabIndex = 11;
            // 
            // pole_tekstowe_r
            // 
            this.pole_tekstowe_r.Location = new System.Drawing.Point(617, 196);
            this.pole_tekstowe_r.Name = "pole_tekstowe_r";
            this.pole_tekstowe_r.Size = new System.Drawing.Size(142, 20);
            this.pole_tekstowe_r.TabIndex = 12;
            this.pole_tekstowe_r.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // pole_tekstowe_h
            // 
            this.pole_tekstowe_h.Location = new System.Drawing.Point(617, 220);
            this.pole_tekstowe_h.Name = "pole_tekstowe_h";
            this.pole_tekstowe_h.Size = new System.Drawing.Size(142, 20);
            this.pole_tekstowe_h.TabIndex = 13;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pole_tekstowe_h);
            this.Controls.Add(this.pole_tekstowe_r);
            this.Controls.Add(this.pole_tekstowe_c);
            this.Controls.Add(this.pole_tekstowe_b);
            this.Controls.Add(this.pole_tekstowe_a);
            this.Controls.Add(this.dlugosc_boku_h);
            this.Controls.Add(this.dlugosc_boku_r);
            this.Controls.Add(this.dlugosc_boku_c);
            this.Controls.Add(this.dlugosc_boku_b);
            this.Controls.Add(this.dlugosc_boku_a);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label_figura);
            this.Controls.Add(this.figura_obrazek);
            this.Name = "Form2";
            this.Text = "Podaj wartości";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.figura_obrazek)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.PictureBox figura_obrazek;
        public System.Windows.Forms.Label label_figura;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label dlugosc_boku_a;
        public System.Windows.Forms.Label dlugosc_boku_b;
        public System.Windows.Forms.TextBox pole_tekstowe_a;
        public System.Windows.Forms.TextBox pole_tekstowe_b;
        public System.Windows.Forms.Label dlugosc_boku_c;
        public System.Windows.Forms.Label dlugosc_boku_r;
        public System.Windows.Forms.Label dlugosc_boku_h;
        public System.Windows.Forms.TextBox pole_tekstowe_c;
        public System.Windows.Forms.TextBox pole_tekstowe_r;
        public System.Windows.Forms.TextBox pole_tekstowe_h;
    }
}